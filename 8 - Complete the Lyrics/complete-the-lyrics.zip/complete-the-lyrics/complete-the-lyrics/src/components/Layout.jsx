import { Outlet } from "react-router-dom";
import SingerNav from "./SingerNav.jsx";

// Shared layout: title + singer tabs stay on screen for every route.
export default function Layout() {
  return (
    <div className="app">
      <h1 className="title">Complete the Lyrics</h1>
      <SingerNav />
      <Outlet />
    </div>
  );
}
