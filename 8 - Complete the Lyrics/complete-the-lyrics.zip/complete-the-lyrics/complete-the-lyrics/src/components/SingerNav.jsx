import { NavLink } from "react-router-dom";
import { singers } from "../data/singers.js";

export default function SingerNav() {
  return (
    <nav className="tabs" aria-label="Singers">
      {singers.map((singer) => (
        <NavLink
          key={singer.id}
          to={`/singer/${singer.id}`}
          className={({ isActive }) => (isActive ? "tab active" : "tab")}
          style={{ backgroundColor: singer.color }}
        >
          {singer.name}
        </NavLink>
      ))}
    </nav>
  );
}
