import { getSinger } from "../data/singers.js";

// Renders committed lines plus the live "draft" bar (only while typing).
export default function LyricsContainer({ lines, draft, draftColor }) {
  return (
    <div className="lyrics-box">
      {lines.map((line) => (
        <div
          key={line.id}
          className="lyric-bar"
          style={{ backgroundColor: getSinger(line.singerId)?.color }}
        >
          {line.text}
        </div>
      ))}
      {draft.trim() !== "" && (
        <div className="lyric-bar" style={{ backgroundColor: draftColor }}>
          {draft}
        </div>
      )}
    </div>
  );
}
