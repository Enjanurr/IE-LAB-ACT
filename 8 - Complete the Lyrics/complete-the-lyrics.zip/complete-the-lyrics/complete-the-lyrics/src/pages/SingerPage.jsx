import { useState, useRef, useLayoutEffect } from "react";
import { useParams } from "react-router-dom";
import { getSinger } from "../data/singers.js";
import LyricsContainer from "../components/LyricsContainer.jsx";
import NotFound from "./NotFound.jsx";

// One reusable page for every singer: useParams picks the data.
export default function SingerPage({ lines, addLine }) {
  const { singerId } = useParams();
  const singer = getSinger(singerId);
  const [draft, setDraft] = useState("");

  // Always holds the latest draft text so the cleanup below can read it.
  const draftRef = useRef("");
  draftRef.current = draft;

  // When the singer changes (or the page unmounts), commit any unfinished
  // text as its own bar in the OLD singer's color, then start a clean draft.
  // Layout effect = runs before paint, so there is no color flicker.
  useLayoutEffect(() => {
    return () => {
      const text = draftRef.current.trim();
      if (text && singer) addLine(singer.id, text);
      setDraft("");
    };
  }, [singerId]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!singer) {
    return (
      <NotFound
        title="Singer Not Found"
        message={`There is no singer with the ID "${singerId}".`}
      />
    );
  }

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      commit();
    }
  };

  const commit = () => {
    const text = draft.trim();
    if (!text) return;
    addLine(singer.id, text);
    setDraft("");
  };

  return (
    <div className="singer-page">
      <input
        key={singer.id}
        className="lyric-input"
        type="text"
        value={draft}
        placeholder={singer.prompt}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={handleKeyDown}
        aria-label={`Lyric line for ${singer.name}`}
        autoFocus
      />

      <LyricsContainer lines={lines} draft={draft} draftColor={singer.color} />

    
    </div>
  );
}
