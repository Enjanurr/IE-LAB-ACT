import { Link } from "react-router-dom";

// Used for the wildcard route (404) and for unknown singer IDs.
export default function NotFound({
  title = "404 Not Found",
  message = "That page does not exist.",
}) {
  return (
    <div className="not-found">
      <h2>{title}</h2>
      <p>{message}</p>
      <Link className="back-link" to="/">
        ← Go Home
      </Link>
    </div>
  );
}
