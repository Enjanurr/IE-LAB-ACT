import { useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Layout from "./components/Layout.jsx";
import SingerPage from "./pages/SingerPage.jsx";
import NotFound from "./pages/NotFound.jsx";

export default function App() {
  // Committed lyric lines live here so they survive route changes
  // (switching singers must not wipe the song).
  const [lines, setLines] = useState([]);

  const addLine = (singerId, text) =>
    setLines((prev) => [...prev, { id: crypto.randomUUID(), singerId, text }]);

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Navigate to="/singer/first-singer" replace />} />
        <Route
          path="/singer/:singerId"
          element={<SingerPage lines={lines} addLine={addLine} />}
        />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
