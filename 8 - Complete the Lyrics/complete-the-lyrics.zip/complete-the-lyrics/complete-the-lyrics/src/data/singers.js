// Singer metadata. `id` is URL-safe and used in /singer/:singerId
export const singers = [
  {
    id: "first-singer",
    name: "First Singer",
    color: "#A58BE4",
    prompt: "Type the next line of the song...",
  },
  {
    id: "second-singer",
    name: "Second Singer",
    color: "#A1DB63",
    prompt: "What does the second singer sing?",
  },
  {
    id: "third-singer",
    name: "Third Singer",
    color: "#3DBE9D",
    prompt: "Add the third singer's line...",
  },
  {
    id: "fourth-singer",
    name: "Fourth Singer",
    color: "#ED81B4",
    prompt: "Finish the lyric as the fourth singer...",
  },
];

export const getSinger = (id) => singers.find((s) => s.id === id);
