# Complete the Lyrics

React + Vite + React Router lab. Pick a singer, type a lyric line, and watch it appear live as a colored bar. Press **Enter** to commit the line.

## Installation & Run

```bash
npm install
npm run dev
```

Open the URL Vite prints (usually http://localhost:5173).

Production build: `npm run build` then `npm run preview`.

## Route Map

| Path                  | View                              |
| --------------------- | --------------------------------- |
| `/`                   | Home (title + singer tabs)        |
| `/singer/:singerId`   | Singer view (input + lyrics box)  |
| `/singer/unknown-id`  | "Singer Not Found" with Home link |
| `*`                   | 404 Not Found with Home link      |

Valid IDs: `first-singer`, `second-singer`, `third-singer`, `fourth-singer`.

## Structure

```
src/
  main.jsx                  BrowserRouter setup
  App.jsx                   Routes + shared lyric lines state
  data/singers.js           Singer metadata (id, name, color, prompt)
  components/Layout.jsx     Shared title + tabs + <Outlet />
  components/SingerNav.jsx  NavLink tabs
  components/LyricsContainer.jsx  Committed bars + live draft bar
  pages/Home.jsx
  pages/SingerPage.jsx      One reusable page for all singers
  pages/NotFound.jsx        404 and Singer Not Found
```

## How it works

**Link / NavLink** render real `<a href>` elements but intercept the click and update the URL through the History API, so the page changes without a full reload. `NavLink` also knows whether its `to` matches the current URL, which is used here to style the active singer tab.

**useParams** reads the dynamic segment of the URL (`:singerId`). `SingerPage` looks that ID up in `data/singers.js`, so a single component serves every singer. If no singer matches, it renders a "Singer Not Found" view.

## Screenshots

Add screenshots here before submitting:

- Home page (`/`)
- `/singer/first-singer`
- `/singer/third-singer`

## Reflection Answers

1. **useState vs routing:** useState changes what is rendered but not the URL, so there is no Back/Forward support, no bookmarking or sharing, and refresh loses the view.
2. **useParams:** it exposes the URL segment, so one component looks up different data per URL.
3. **`/singer/unknown`:** the route matches, the lookup returns undefined, and the page shows "Singer Not Found" with a Home link.
4. **Link vs `<a>`:** a plain anchor triggers a full page reload and resets app state; Link navigates client-side.
