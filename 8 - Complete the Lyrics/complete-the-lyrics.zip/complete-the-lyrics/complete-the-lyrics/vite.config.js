import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// The dev server falls back to index.html for unknown paths,
// so refreshing on /singer/first-singer works.
export default defineConfig({
  plugins: [react()],
});
